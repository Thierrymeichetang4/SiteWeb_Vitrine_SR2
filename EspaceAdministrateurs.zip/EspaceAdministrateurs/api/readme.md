# api_gl2b
# API_EN_PHP
# DESIGN PATTERN CHOISI EST: MVC

Pour le lancer il suffit d'aller sur le navigateur et taper "localhost/api2/api.php

# MODIFICATION
pour l'adapter faut changer simplement les configurations de la bd dans le dossier config

# GERMANN